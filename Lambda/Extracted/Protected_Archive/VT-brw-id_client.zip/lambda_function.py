import json

def lambda_handler(event, context):
    # TODO implement
    print(f'Request event: {event}')
    return event
    
