import json
"""
def construct_command(ssh_client, deployment_initiators):
    '''
    Lambda will timeout before it can the command finish executing
    So create a series of command and send it once to EC2 instance
    '''
    
    cmd_str = ''
    
    ##Arrange the deployment sequence based on the YML list arrangement
    print (f'Arranging the deployment sequence')
    arranged_deployment_initiator = []
    for deployment_file in DEPLOYMENT_YAML_FILES:
        for file in deployment_initiators:
            if deployment_file in file:
                arranged_deployment_initiator.append(file)
                print(f'  -- {file}')
                break;
                
    print (f'Executing deployment')
    for file in arranged_deployment_initiator:
        directory = os.path.dirname(file)
        output_log_file = EC2_LOG_FILE.format(f'{EC2_HOME_DIR}/{directory}')
        
        command = 'ansible-playbook {0} {1}; '.format(
            file,
            output_log_file
        )
        cmd_str += command
        
    print ("Executing {}".format(cmd_str))
    stdin , stdout, stderr = ssh_client.exec_command(cmd_str)
    
    print(f"Command was queried {stdout.read()}")
    print(f"Command was queried error {stderr.read()}")
        

def create_ec2_dirs(ssh_client, deployment_files):
    '''
    Create the directories for the deployment
    '''
    cmd_str = ''
    for file in deployment_files:
        command = f'mkdir -p {EC2_HOME_DIR}/{os.path.dirname(file)}; '
        cmd_str += command
    print ("Creating dir {}".format(cmd_str))
    stdin , stdout, stderr = ssh_client.exec_command(cmd_str)
    

def send_payload(ssh_client, local_file, remote_file):
    '''
    Send payload to EC2
    '''
    try:
        
        sftp_client = ssh_client.open_sftp()
        sftp_client.put(local_file, remote_file)
        sftp_client.close()
        print(f'File saved to {remote_file}')
    except Exception as e:
        print(f'[Error] send_payload {e.args}')
        
        
def send_multiple_payloads(ssh_client, local_filenames, tmp_dir):
    '''
    Send multiple payload to EC2
    '''
    try:
        
        sftp_client = ssh_client.open_sftp()
        for local_file in local_filenames:
            print(f'{local_file} sent to remote server')
            to_ec2_file = f'{EC2_HOME_DIR}/{local_file}'
            
            sftp_client.put(f'/{tmp_dir}/{local_file}', to_ec2_file)
        sftp_client.close()
    except Exception as e:
        print(f'[Error] send_payload {e.args}')
        
        
        
def list_target_files(yml_file):
    '''
    Extract the target files from the YML file
    '''
    target_files = []
    try:
        with open(yml_file, 'r') as playbook:
            docs = yaml.load(playbook, Loader=yaml.FullLoader) 
            
            #Top heirarchy
            for document in docs:
                for item in document['tasks']:
                    for targetFile in item['loop']:
                        print(targetFile['name'])
                        target_files.append(f'{targetFile["name"]}.zip')
                        
    except Exception as e:
        print(f'[Error] list_target_files {e.args}')
    
    return target_files
    

def deploy_uService(host, target_uservice):
    '''
    Deploys the requested service
    '''

    ssh_client = None
    try:
        
        s3_client = boto3.client('s3')
        s3_client.download_file(S3_BUCKET, INSTANCE_KEYPAIR, SAVE_FILE)
        tmp_dir = '/tmp'
        deployment_files = []
        deployment_initiators = []
        
        # Create SSH client
        keypair = paramiko.RSAKey.from_private_key_file(SAVE_FILE)
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        print( "Connecting to " + host )
        ssh_client.connect( hostname = host, username = USERNAME, pkey = keypair )
        print ("Connected to " + host)
        
        
        ##Cleanup if previous deployment has residue
        clean_temp_dir(tmp_dir, TARGET_FILE)
        
        ##List and download all the files that belongs to the uService
        target_bucket = f'{S3_USERVICES_DIR}{target_uservice}'
        uService_objects = s3_client.list_objects(
            Bucket = S3_BUCKET,
            Prefix = target_bucket
        )  
        
        if uService_objects.get('Contents'):
            for content in uService_objects.get('Contents'):
                if (content.get('Key')):
                    local_file = f'{tmp_dir}/{content.get("Key")}'
                    dir_to_save = os.path.dirname(local_file)
                    deployment_files.append(content.get("Key"))
                    
                    ## Take note of the yml file location then execute later
                    for initiator in DEPLOYMENT_YAML_FILES:
                        if initiator in content.get("Key"):
                            deployment_initiators.append(content.get("Key"))
                            break
                        
                    if (not os.path.exists(dir_to_save)):
                        # print(f'\n***Creating directory: {dir_to_save}***')
                        os.makedirs(dir_to_save)
                        
                    s3_client.download_file( S3_BUCKET, content.get('Key'), local_file )
                    print(f'{local_file} downloaded')
                    
            print('All uService files has been downloaded')
            
            print('Creating directory in the server')
            create_ec2_dirs(ssh_client, deployment_files)
            
            print('Transfering files to server')
            send_multiple_payloads(ssh_client, deployment_files, tmp_dir)
            
            print('Beginning the deployment execution')
            construct_command(ssh_client, deployment_initiators)
            
            print('Command to deploy was sent')
            
            ssh_client.close()
            
        else:
            
            print('Deployment failed no  deployment files')
            
    except Exception as e:
        print(f'[Error] deploy_uService {e.args}')
    finally:
        if ssh_client:
            ssh_client.close()
            
    
def get_ec2_ipv4(instances):
    '''
    Will return the dynamic public IP of the instance if it is online
    Supports only 1 instance for now (1st intance found)
    '''
    
    main_key = 0
    ec2_client = boto3.client('ec2')
    filters = [{  
        'Name': 'instance-id',
        'Values': INSTANCES
    }]
    
    instances = ec2_client.describe_instances(Filters=filters)
    # print(instances['Reservations'])
    
    if instances and ('Instances' in instances['Reservations'][main_key].keys()):
        for r in instances['Reservations']:
            for inst in r['Instances']:
                if( 'PublicIpAddress' in inst.keys()):
                    return inst['PublicIpAddress']
                    
    return ''
    

def clean_temp_dir(folder, except_file):
    print('**Trying to delete in temp**')
    
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        try:
            if (except_file in file_path):
                pass
            else:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                    print(f'unlinked {file_path}')
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
                    print(f'rmtree {file_path}')
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))
        
    print('--Trying to delete in temp--')"""
    
    
def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
