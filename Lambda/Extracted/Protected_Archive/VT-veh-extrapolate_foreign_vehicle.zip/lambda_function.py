"""
    Extrapolate the current location of foreign vehicle(s)
    based on the location of the vehicle recording the video
"""
import json

def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
