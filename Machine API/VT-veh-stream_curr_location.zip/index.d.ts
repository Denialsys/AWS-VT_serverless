export function handler(event: any, context: any, callback: any): Promise<any>;
//# sourceMappingURL=index.d.ts.map